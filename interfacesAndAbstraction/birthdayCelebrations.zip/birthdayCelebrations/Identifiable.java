package interfacesAndAbstraction.birthdayCelebrations;

public interface Identifiable {
    String getId();
}

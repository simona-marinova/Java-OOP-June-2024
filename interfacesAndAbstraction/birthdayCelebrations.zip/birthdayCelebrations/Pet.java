package interfacesAndAbstraction.birthdayCelebrations;

public class Pet implements  Birthable{
    String name;
    String birthDate;

    public Pet(String name, String birthDate) {
        this.name = name;
        this.birthDate = birthDate;
    }

    @Override
    public String getBirthDate() {
        return birthDate;
    }

    public String getName() {
        return name;
    }
}

package interfacesAndAbstraction.birthdayCelebrations;

public interface Birthable {
    String getBirthDate();
}

package workingWithAbstraction.trafficLights;

public enum TrafficLight {
    RED,
    GREEN,
    YELLOW;


}

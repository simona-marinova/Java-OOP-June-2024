package workingWithAbstraction.cardSuit;

public enum CardSuite {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;


}

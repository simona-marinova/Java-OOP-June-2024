package workingWithAbstraction.cardsThree;

public class Card {
    private int cardPower;

    public Card(int cardPower) {
        this.cardPower = cardPower;
    }

    public int getCardPower() {
        return cardPower;
    }
}
